package com.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SQLManager {

	private Connector connector;

	private Statement statement;

	private PreparedStatement preparedStatement;

	private Connection connection;

	public SQLManager() {
		try {
			connector = new Connector();
			statement = connector.getStatement();
			connection = connector.getConnection();
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public List<String> getPolygon(String arg) {
		String sql = "SELECT row_to_json(fc) FROM ( SELECT 'geojson' As type, f As data FROM (SELECT 'Feature' As type, name, ST_AsGeoJSON((ST_Transform (way, 4326)))::json As geometry FROM planet_osm_polygon where name = ?  )As f )  As fc;";

		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setString(1, arg);
			List<String> geoJsons = new ArrayList<>();
			ResultSet result = ps.executeQuery();
			while (result.next()) {

				String s = result.getString(1);

				/*
				 * JSONObject json = new JSONObject(); json.put("type",
				 * "Feature"); json.put("data", result.getString(1));
				 * 
				 * System.out.println(result.getString(1));
				 */
				System.out.println(s);
				geoJsons.add(s);

			}
			return geoJsons;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<String> findObject(Float lng, Float lat) {

		try {
			PreparedStatement ps = connection.prepareStatement(Queries.GET_OBJECT);
			ps.setFloat(1, lng);
			ps.setFloat(2, lat);
			List<String> geoJsons = new ArrayList<>();
			ResultSet result = ps.executeQuery();
			while (result.next()) {

				String s = result.getString(1);

				System.out.println(s);
				geoJsons.add(s);

			}
			return geoJsons;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<String> getParking(String name, Float distance) {
		try {
			PreparedStatement ps = connection.prepareStatement(Queries.GET_PARKING_POLYGON_POINT);
			ps.setString(1, name);
			ps.setFloat(2, distance);
			ps.setString(3, name);
			ps.setFloat(4, distance);
			List<String> geoJsons = new ArrayList<>();
			ResultSet result = ps.executeQuery();
			while (result.next()) {

				String s = result.getString(1);

				System.out.println(s);
				geoJsons.add(s);

			}
			
			
			if(geoJsons.size() == 0 ) {
				PreparedStatement ps1 = connection.prepareStatement(Queries.GET_PARKING_LINE);
				ps1.setString(1, name);
				ps1.setFloat(2, distance);
				ResultSet result1 = ps1.executeQuery();
				while (result1.next()) {

					String s = result1.getString(1);

					System.out.println(s);
					geoJsons.add(s);

				}
			}
			
			return geoJsons;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
	public List<String> getATMs(String name, Float distance) {
		String sql = "SELECT row_to_json(fc) FROM ( SELECT 'geojson' As type, f As data FROM (SELECT 'Feature' As type, name, ST_AsGeoJSON((ST_Transform (way, 4326)))::json As geometry FROM planet_osm_polygon AS p where amenity='parking' and st_dwithin(ST_Transform (p.way, 26986),(select st_transform(way,26986) from planet_osm_polygon where name=? limit 1),?)) As f )  As fc;";

		try {
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setString(1, name);
			ps.setFloat(2, distance);
			List<String> geoJsons = new ArrayList<>();
			ResultSet result = ps.executeQuery();
			while (result.next()) {

				String s = result.getString(1);

				System.out.println(s);
				geoJsons.add(s);

			}
			return geoJsons;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public float getParkingArea(String name) {

		try {
			PreparedStatement ps = connection.prepareStatement(Queries.GET_PARKING_AREA);
			ps.setString(1, name);
			float area = 0;
			ResultSet result = ps.executeQuery();
			while (result.next()) {
				area = result.getFloat(1);
			}
			return area;

		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	public double getParkingAreaSum(String name, Float distance) {

		try {
			PreparedStatement ps = connection.prepareStatement(Queries.GET_PARKING_AREA_SUM);
			ps.setString(1, name);
			ps.setFloat(2, distance);
			double area = 0;
			ResultSet result = ps.executeQuery();

			while (result.next()) {
				area = result.getDouble(1);
			}
			return area;

		} catch (SQLException e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	
	public List<String> getObject(String name) {

		try {
			PreparedStatement ps = connection.prepareStatement(Queries.GET_PLACE);
			ps.setString(1, name);
			List<String> geoJsons = new ArrayList<>();
			ResultSet result = ps.executeQuery();
			while (result.next()) {
				String s = result.getString(1);
				geoJsons.add(s);

			}
			return geoJsons;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
	public List<String> getLargestParking(String name, Float distance) {
		try {
			PreparedStatement ps = connection.prepareStatement(Queries.GET_LARGEST_PARKING);
			ps.setString(1, name);
			ps.setFloat(2, distance);
			List<String> geoJsons = new ArrayList<>();
			ResultSet result = ps.executeQuery();
			while (result.next()) {

				String s = result.getString(1);

				System.out.println(s);
				geoJsons.add(s);

			}
			
			return geoJsons;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
	
	public List<String> getParkingRoads(String name, Float distance) {
		try {
			PreparedStatement ps = connection.prepareStatement(Queries.GET_PARKING_LINE);
			ps.setString(1, name);
			ps.setFloat(2, distance);
			List<String> geoJsons = new ArrayList<>();
			ResultSet result = ps.executeQuery();
			while (result.next()) {

				String s = result.getString(1);

				System.out.println(s);
				geoJsons.add(s);

			}
			return geoJsons;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
	
	
	
}
