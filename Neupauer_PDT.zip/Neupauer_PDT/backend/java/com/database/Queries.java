package com.database;

public class Queries {
	
	
	public static String GET_PARKING_POLYGON_POINT = "WITH parking AS ( "
			+ "SELECT 'Feature' AS type, name,access, ST_AsGeoJSON((ST_Transform (way, 4326)))::jsonb AS geometry "
			+ "FROM planet_osm_polygon AS p WHERE amenity='parking' "
			+ "AND ST_Dwithin(ST_Transform (p.way, 26986)"
			+ ",(SELECT st_transform(way,26986) "
			+ "FROM planet_osm_polygon WHERE name=? limit 1),?) "
			+ "UNION "
			+ "SELECT 'Feature' AS type, name, access, "
			+ "ST_AsGeoJSON((ST_Transform (way, 4326)))::jsonb AS geometry "
			+ "FROM planet_osm_point AS p WHERE amenity='parking'AND "
			+ "ST_Dwithin(ST_Transform (p.way, 26986),"
			+ "(SELECT st_transform(way,26986) FROM planet_osm_polygon "
			+ "WHERE name=? limit 1),?) )SELECT row_to_json(fc) "
			+ "FROM ( SELECT 'geojson' As type, f As data FROM parking as f) as fc";
	
	
	
	public static String GET_PARKING_LINE = "SELECT row_to_json(fc) FROM ( SELECT 'geojson' As type, "
			+ "f As data FROM (SELECT 'Feature' As type, name, "
			+ "ST_AsGeoJSON((ST_Transform (way, 4326)))::jsonb As geometry FROM  "
			+ "planet_osm_line p where p.highway='secondary'  and "
			+ "st_dwithin(ST_Transform (p.way, 26986), (select st_transform(way,26986) "
			+ "from planet_osm_polygon where name=? limit 1),?)) As f )  As fc";
	
	
	public static String GET_OBJECT = "SELECT row_to_json(fc) FROM "
			+ "(SELECT 'geojson' As type, f As data FROM "
			+ "(SELECT 'Feature' As type, p.name, "
			+ "min(st_distance(st_setsrid(st_MakePoint(?,?),4269),st_transform(p.way,4269))) as distance, "
			+ "ST_AsGeoJSON((ST_Transform (p.way, 4326)))::json As geometry "
			+ "FROM planet_osm_polygon p where amenity IS NOT NULL and name IS NOT NULL "
			+ "group by p.name,p.way order by distance limit 1 )As f )  As fc";
	
	public static String GET_PARKING_AREA;
	
	public static String GET_PARKING_AREA_SUM = "SELECT round(sum(st_area(st_transform(way,26986)))::numeric,2)"
			+ "FROM planet_osm_polygon AS p WHERE amenity='parking' "
			+ "AND ST_Dwithin(ST_Transform (p.way, 26986)"
			+ ",(SELECT st_transform(way,26986) "
			+ "FROM planet_osm_polygon WHERE name=? limit 1),?)";

	
	public static String GET_PLACE = "SELECT row_to_json(fc) FROM ( SELECT 'geojson' As type, "
			+ "f As data FROM (SELECT 'Feature' As type, name, "
			+ "ST_AsGeoJSON((ST_Transform (way, 4326)))::jsonb As geometry FROM  "
			+ "planet_osm_polygon p where name=?) As f )  As fc";
	
	public static String GET_LARGEST_PARKING = "SELECT row_to_json(fc) FROM ( SELECT 'geojson' As type,"
			+ " f As data FROM (SELECT 'Feature' As type, name, "
			+ "round(max(st_area(st_transform(way,26986)))::numeric,2) as area,ST_AsGeoJSON((ST_Transform (p.way, 4326)))::json As geometry "
			+ "FROM planet_osm_polygon AS p WHERE amenity='parking' "
			+ "AND ST_Dwithin(ST_Transform (p.way, 26986)"
			+ ",(SELECT st_transform(way,26986) "
			+ "FROM planet_osm_polygon WHERE name=? limit 1),?) GROUP BY p.area,p.way,p.name ORDER BY area DESC limit 1)   As f )  As fc";

}
