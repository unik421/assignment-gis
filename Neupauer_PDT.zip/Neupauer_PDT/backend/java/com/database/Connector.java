package com.database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Connector {
	private Connection connection;
	
	private Statement statement;

	private PreparedStatement preparedStatement;
	
	public Connector() throws SQLException, ClassNotFoundException {
		createConnection();
	}
	
	private void createConnection() throws SQLException, ClassNotFoundException {
		Class.forName("org.postgresql.Driver"); 
		connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/gis", "postgres", "123456");
		statement = connection.createStatement();
		
	}
	
	public Statement getStatement() {
		return statement;
	}
	
	public Connection getConnection() {
		return this.connection;
	}
}