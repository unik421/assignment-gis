package com.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.database.SQLManager;
@RestController
public class DataController {

	
	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(value="/polygon",method = RequestMethod.GET)
	public ResponseEntity<?> findPolygon(@RequestParam Float lng, @RequestParam Float lat) {
		SQLManager m = new SQLManager();
		List<String> list = m.findObject(lng,lat);	
		ResponseEntity<?> entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
	
	
	
	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(value="/parking",method = RequestMethod.GET)
	public ResponseEntity<?> getParking(@RequestParam String name, @RequestParam Float distance) {
		SQLManager m = new SQLManager();
		List<String> list = m.getParking(name,distance);	
		ResponseEntity<?> entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
	
	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(value="/parking/area",method = RequestMethod.GET)
	public ResponseEntity<?> getParkingArea(@RequestParam String name, @RequestParam Float distance) {
		SQLManager m = new SQLManager();
		double area  = m.getParkingAreaSum(name,distance);	
		ResponseEntity<?> entity = new ResponseEntity<>(area, HttpStatus.OK);
		return entity;
	}
	
	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(value="/place",method = RequestMethod.GET)
	public ResponseEntity<?> getPlace(@RequestParam String name) {
		SQLManager m = new SQLManager();
		List<String> list = m.getObject(name);	
		ResponseEntity<?> entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
	
	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(value="/parking/largest",method = RequestMethod.GET)
	public ResponseEntity<?> getLargestParking(@RequestParam String name, @RequestParam Float distance) {
		SQLManager m = new SQLManager();
		List<String> list = m.getLargestParking(name,distance);	
		ResponseEntity<?> entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
	
	@CrossOrigin(origins = "http://localhost:8080")
	@RequestMapping(value="/parking/roads",method = RequestMethod.GET)
	public ResponseEntity<?> getParkingRoads(@RequestParam String name, @RequestParam Float distance) {
		SQLManager m = new SQLManager();
		List<String> list = m.getParkingRoads(name,distance);	
		ResponseEntity<?> entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
	
	
}
