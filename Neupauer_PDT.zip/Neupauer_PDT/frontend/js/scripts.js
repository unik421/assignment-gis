var API = "http://localhost:8080/";
var map;
var lng;
var lat;
var id_largest = '';
var id_largest_marker = '';
var layer = '';
var parkingLayers = [];
var markersLayers = [];
var parkingLayersRoads = [];
var object;
$(document).ready(function() {
    mapboxgl.accessToken = 'pk.eyJ1IjoidW5pazQyMSIsImEiOiJjaXR6eHp6eGEwMDU3MnpwMWswaWJsZmx5In0.mRHjCpPD6DSL0QJfmBPcjQ';
    map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/unik421/ciu9ykmf8002z2io68utuh7ru',
        center: [17.1, 48.1],
        zoom: 11
    });

    map.on('click', function(e) {


        lng = JSON.stringify(e.lngLat.lng)
        lat = JSON.stringify(e.lngLat.lat)
        console.log(lng + "    " + lat)

        $.ajax({
            url: API + "polygon?lng=" + lng + "&lat=" + lat
        }).then(function(response) {

            refreshPlaces();
            refreshParkings();
            for (i in response) {
                var parsed = jQuery.parseJSON(response[i])
                object = parsed.data.name;
                layer = 'place' + i;
                $('#place').val(parsed.data.name);
                map.addSource(layer, parsed);
                map.addLayer({
                    'id': layer,
                    'type': 'fill',
                    'source': layer,
                    'layout': {},
                    'paint': {
                        'fill-color': '#ff00ff',
                        'fill-opacity': 0.3
                    }
                });
            }

        });
    })


    $("#refresh").click(function() {
        refreshPlaces();
        refreshParkings();
    });


    $("#send").click(function() {
        refreshParkings();
        $.ajax({
            url: API + "parking?name=" + object + "&distance=" + $('#distance').val()
        }).then(function(response) {

            for (j in response) {
                var parsed = jQuery.parseJSON(response[j])
                var id = 'parking' + j;
                var access = parsed.data.access;
                var color = null;



                if (access === 'private' || access === 'no') {
                    color = '#ff0000';
                } else if (access === 'public' || access === 'yes') {
                    color = '#0000ff';
                } else if (access === 'customers') {
                    color = '#00ffff';
                } else {
                    color = '#ffff00';
                }

                map.addSource(id, parsed);

                if (parsed.data.geometry.type == 'Polygon') {
                    markersLayers.push(id+"icon");
                    parkingLayers.push(id);
                    map.addLayer({
                        'id': id,
                        'type': 'fill',
                        'source': id,
                        'layout': {},
                        'paint': {
                            'fill-color': color,
                            'fill-opacity': 0.5
                        }
                    })
                    map.addLayer({
                        "id": id + "icon",
                        "source": id,
                        "type": "symbol",
                        "layout": {
                            "icon-image": "turning-circle-outline",
                            "text-field": "P",
                            "icon-size": 0.5
                        },
                        'paint': {
                            'text-color': color
                        }
                    });
                } else if (parsed.data.geometry.type == 'LineString') {
                    map.addLayer({
                        'id': id,
                        'type': 'line',
                        'source': id,
                        'layout': {},
                        'paint': {
                            'line-color': '#0000ff',
                            'line-width': 2.5
                        }
                    });
                } else if (parsed.data.geometry.type == 'Point') {
                    markersLayers.push(id+"icon");
                    map.addLayer({
                        "id": id+"icon",
                        "source": id,
                        "type": "symbol",
                        "layout": {
                            "icon-image": "turning-circle-outline",
                            "text-field": "P",
                            "icon-size": 0.5
                        },
                        'paint': {
                            'text-color': color
                        }

                    });
                }
            }

        });
    });



    function refreshPlaces() {        
        if(layer!='') {
            map.removeLayer(layer);
            map.removeSource(layer);
        }
        if(id_largest != '') {
            map.removeLayer(id_largest);
            map.removeSource(id_largest);
        }
        if(id_largest_marker != '') {
            map.removeLayer(id_largest_marker);
        }
        layer = '';
        id_largest = '';
        id_largest_marker = '';
    }

    function refreshParkings() {
        for (f in parkingLayers) {
            map.removeLayer(parkingLayers[f]);
            map.removeSource(parkingLayers[f]);
        }

        for (o in markersLayers) {
            map.removeLayer(markersLayers[o]);
        }

        for(p in parkingLayersRoads) {
            map.removeLayer(parkingLayersRoads[p]);
            map.removeSource(parkingLayersRoads[p]);
        }

        parkingLayers = [];
        markersLayers = [];
        parkingLayersRoads = [];
    }

    $("#findRoads").click(function() {

        refreshParkings();
        $.ajax({
            url: API + "parking/roads?name=" + object + "&distance=" + $('#distance').val()
        }).then(function(response) {
            for (j in response) {
                var parsed = jQuery.parseJSON(response[j])
                var id = 'parkingRoad' + j;

                parkingLayersRoads.push(id);
                var color = null;

                map.addSource(id, parsed);
                map.addLayer({
                    'id': id,
                    'type': 'line',
                    'source': id,
                    'layout': {},
                    'paint': {
                        'line-color': '#0000ff',
                        'line-width': 2.5
                    }
                });
            }
        });
    });


    $("#find").click(function() {
        refreshPlaces();
        $.ajax({
            url: API + "place?name=" + $('#place').val()
        }).then(function(response) {
            var parsed = jQuery.parseJSON(response);
            object = parsed.data.name;
            var id = "0";
            //layers.push(id);
            map.addSource(id, parsed);
            map.addLayer({
                'id': id,
                'type': 'fill',
                'source': id,
                'layout': {},
                'paint': {
                    'fill-color': '#00ff00',
                    'fill-opacity': 0.3
                }
            });
        });
    });


    $("#areaSum").click(function() {
        refreshParkings();
        $.ajax({
            url: API + "parking/area?name=" + object + "&distance=" + $('#distance').val()
        }).then(function(response) {
            var parsed = jQuery.parseJSON(response);
            console.log(parsed);
            $("#sum").html("Parking area : " + parsed + " m2");
        });
    });

    $("#largest").click(function() {
        refreshParkings();
        $.ajax({
            url: API + "parking/largest?name=" + object + "&distance=" + $('#distance').val()
        }).then(function(response) {
            var parsed = jQuery.parseJSON(response);
            console.log(parsed);
            id_largest = "largest";
            id_largest_marker = id_largest + "marker";
            map.addSource(id_largest, parsed);
            map.addLayer({
                'id': id_largest,
                'type': 'fill',
                'source': id_largest,
                'layout': {},
                'paint': {
                    'fill-color': '#00ff00',
                    'fill-opacity': 0.3
                }
            });

            map.addLayer({
                "id": id_largest_marker,
                "source": id_largest,
                "type": "symbol",
                "layout": {
                    "text-field": parsed.data.area + " m2"
                }
            });
            $("#largestArea").html("Largest area : " + parsed.data.area + " m2");
        });
    });
});